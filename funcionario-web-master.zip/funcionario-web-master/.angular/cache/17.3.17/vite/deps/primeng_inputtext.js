import {
  InputText,
  InputTextModule
} from "./chunk-VLBR54GI.js";
import "./chunk-DJAXFXFY.js";
import "./chunk-MW6N3XTI.js";
import "./chunk-T76FZRMF.js";
import "./chunk-6JJ7KVRE.js";
import "./chunk-T4QU4GDF.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
