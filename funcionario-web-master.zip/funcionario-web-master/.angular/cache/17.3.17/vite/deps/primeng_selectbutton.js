import {
  SELECTBUTTON_VALUE_ACCESSOR,
  SelectButton,
  SelectButtonModule
} from "./chunk-CAHSQY2C.js";
import "./chunk-DJAXFXFY.js";
import "./chunk-GYHLK4JX.js";
import "./chunk-YSWSYYUG.js";
import "./chunk-MW6N3XTI.js";
import "./chunk-T76FZRMF.js";
import "./chunk-6JJ7KVRE.js";
import "./chunk-T4QU4GDF.js";
export {
  SELECTBUTTON_VALUE_ACCESSOR,
  SelectButton,
  SelectButtonModule
};
//# sourceMappingURL=primeng_selectbutton.js.map
