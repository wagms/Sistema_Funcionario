import {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
} from "./chunk-TTXYKWQQ.js";
import "./chunk-DJAXFXFY.js";
import "./chunk-7NFPIS7I.js";
import "./chunk-I54QP7DZ.js";
import "./chunk-P7YJMDED.js";
import "./chunk-GYHLK4JX.js";
import "./chunk-WVUL5KXD.js";
import "./chunk-YSWSYYUG.js";
import "./chunk-MW6N3XTI.js";
import "./chunk-T76FZRMF.js";
import "./chunk-6JJ7KVRE.js";
import "./chunk-T4QU4GDF.js";
export {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
};
//# sourceMappingURL=primeng_calendar.js.map
